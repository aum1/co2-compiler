package types;

public class IntType extends Type {

    public String toString() {
        return "int";
    }
}
