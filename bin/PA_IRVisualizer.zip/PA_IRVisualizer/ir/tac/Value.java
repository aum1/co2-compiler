package ir.tac;

public interface Value extends Visitable {
    public String toString();
    
}