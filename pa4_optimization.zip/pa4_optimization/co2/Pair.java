package co2;

public interface Pair {
    public Symbol symbol();
}
