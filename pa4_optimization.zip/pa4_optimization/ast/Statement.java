package ast;

public interface Statement extends Visitable {

}
