package ast;

public interface Expression extends Visitable {
    public String toString();
}
