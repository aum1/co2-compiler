package types;

public class FloatType extends Type {
    public String toString() {
        return "float";
    }

}
