package types;

public class ArrayType extends Type {

}
