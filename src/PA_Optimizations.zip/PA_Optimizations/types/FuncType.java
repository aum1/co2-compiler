package types;

public class FuncType extends Type {

    private TypeList params;
    private Type returnType;


}
